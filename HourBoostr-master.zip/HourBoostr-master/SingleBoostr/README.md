<p align="center">
  <img src="http://i.imgur.com/GaEOIvh.png"/>
  <p align="center">For Steam users that wish to boost one account while still being able to use their Steam client</p>
  <h2 align="center"><a href="https://github.com/Ezzpify/HourBoostr/releases">DOWNLOAD HERE</a></h2>
</p>

##
##
##

## What is this? (OwO)

The purpose of this program is to allow you to boost games while still being logged in to your Steam account on your PC.

## How to use:

1. Run SingleBoostr
2. Select the games you want to boost in the left list
3. Press Start button

Make sure you are signed into the Steam client.
However, if you aren't then the program will tell you.

## Error messages

* *Don't run this application from the Steam directory.*
 * Place the program on your desktop or anywhere else but the Steam directory.
 
* *Missing SingleBoostr.Game application.*
 * SingleBoostr.Game is needed to boost games. Don't delete that program. If you're missing the file, redownload the program.
 
* *Steam is not running. Please start Steam then run me again.*
 * Steam needs to be running in order for this program to work.
 
* *You're not logged into Steam.*
 * Make sure Steam is running and that you're logged in, else it won't run.
 
* *Either you have 0 games, or something went wrong. Hmm... Are you sure you're logged in?*
 * Make sure you have games in your library and that Steam is running fine.
