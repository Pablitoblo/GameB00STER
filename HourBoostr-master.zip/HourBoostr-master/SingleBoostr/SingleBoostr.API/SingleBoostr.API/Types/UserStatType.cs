﻿namespace SingleBoostr.API.Types
{
  public enum UserStatType
  {
    Invalid,
    Integer,
    Float,
    AverageRate,
    Achievements,
    GroupAchievements,
  }
}
