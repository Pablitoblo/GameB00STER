﻿namespace SingleBoostr.API.Types
{
  public enum ItemQuality
  {
    Invalid,
    Any,
    Normal,
    Common,
    Rare,
    Unique,
  }
}
