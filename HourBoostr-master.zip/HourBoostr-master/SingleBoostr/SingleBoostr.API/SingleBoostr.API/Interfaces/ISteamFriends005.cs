﻿using System;
using System.Runtime.InteropServices;

namespace SingleBoostr.API.Interfaces
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct ISteamFriends005
    {
        public IntPtr GetPersonaName;
    }
}
